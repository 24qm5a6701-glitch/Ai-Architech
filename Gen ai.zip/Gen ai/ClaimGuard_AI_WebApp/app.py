from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open("claimguard_ai_model.pkl", "rb"))
scaler = pickle.load(open("claimguard_ai_scaler.pkl", "rb"))

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    try:
        features = [
            float(request.form.get('age')),
            float(request.form.get('months_as_customer')),
            float(request.form.get('policy_annual_premium')),
            float(request.form.get('total_claim_amount')),
            float(request.form.get('incident_severity')),
            float(request.form.get('number_of_vehicles_involved')),
            float(request.form.get('bodily_injuries')),
            float(request.form.get('witnesses'))
        ]

        final_input = np.array([features])
        final_input = scaler.transform(final_input)

        probability = model.predict_proba(final_input)[0][1]
        risk_score = round(probability * 100, 2)

        if risk_score > 55:
            risk_level = "HIGH RISK"
            color = "red"
        elif risk_score > 35:
            risk_level = "MEDIUM RISK"
            color = "orange"
        else:
            risk_level = "LOW RISK"
            color = "green"

        return render_template("index.html",
                               prediction_text=f"Fraud Probability: {risk_score}%",
                               risk_level=risk_level,
                               color=color)

    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == "__main__":
    app.run(debug=True)
